
![[Pasted image 20231119205755.png]]
![[Pasted image 20231119205802.png]]

![[Pasted image 20231119205601.png]]

![[Pasted image 20231119205625.png]]

![[Pasted image 20231119205632.png]]

![[Pasted image 20231119205657.png]]

![[Pasted image 20231119205703.png]]

![[Pasted image 20231119205732.png]]
![[Pasted image 20231119205741.png]]

![[Pasted image 20231119205828.png]]

![[Pasted image 20231119205937.png]]
![[Pasted image 20231119205944.png]]

![[Pasted image 20231119210040.png]]
![[Pasted image 20231119210046.png]]

![[Pasted image 20231119210215.png]]

![[Pasted image 20231119210221.png]]

![[Pasted image 20231119210230.png]]

![[Pasted image 20231119210259.png]]

![[Pasted image 20231119210310.png]]

![[Pasted image 20231119210321.png]]
![[Pasted image 20231119210347.png]]

![[Pasted image 20231119212120.png]]

![[Pasted image 20231119213241.png]]
![[Pasted image 20231119213255.png]]

![[Pasted image 20231119213306.png]]

![[Pasted image 20231119213314.png]]

![[Pasted image 20231119213339.png]]


![[Pasted image 20231119202134.png]]

![[Pasted image 20231119213451.png]]
![[Pasted image 20231119213500.png]]

![[Pasted image 20231119213538.png]]
![[Pasted image 20231119213544.png]]

![[Pasted image 20231119213605.png]]
![[Pasted image 20231119213612.png]]

![[Pasted image 20231119203205.png]]





![[Pasted image 20231119213625.png]]
![[Pasted image 20231119213637.png]]


![[Pasted image 20231119213648.png]]
![[Pasted image 20231119213655.png]]

![[Pasted image 20231119213722.png]]

![[Pasted image 20231119213731.png]]

![[Pasted image 20231119213737.png]]

![[Pasted image 20231119213743.png]]

![[Pasted image 20231119213749.png]]



